# Ascension Workflow — Phase 1 implementation package

Start with [00_START_HERE.md](00_START_HERE.md), then execute the [master orchestration prompt](01_MASTER_ORCHESTRATION_PROMPT.md).

Target delivery repository: `AI-Ascension/ascension-workflow`.
Authoritative production runtime: `AI-Ascension/sts2-harness`.
Delegation: D0 root → D1 Luna Max leads → D2 Luna Max coordinators → D3 Luna Max specialists.
Scope: headless strict and bounded-dynamic gameplay workflow management only.

This is a self-contained implementation instruction package, not a shipped engine. The source baseline, proposed schemas, synthetic fixtures, task graph, and evidence gates make the instructions reproducible without this conversation. No fonts, game assets, saves, credentials, or provider transcripts are included.
