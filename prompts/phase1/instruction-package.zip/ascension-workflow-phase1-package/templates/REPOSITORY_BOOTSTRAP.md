# New repository bootstrap — execution instruction

Target exactly `AI-Ascension/ascension-workflow`. Bootstrap only when the master prompt is executed under the user's bounded implementation authorization. This package creation did not perform this operation.

Resolve the repository with the connected GitHub account/tool. If it exists, inspect current default branch, instructions, history, dirty local work, relevant issues and PRs before resuming. Do not replace it, rename it, or change visibility. If a tool returns access denied, report that; do not assume it does not exist.

For an absent repository, use the permitted repository-creation operation. Default to private unless the operator's explicit policy says public; do not make existing private artifacts public incidentally. Respect organization visibility restrictions and runtime approvals. If creation tools are unavailable, preserve a local prepared tree and report the exact blocker without inventing a successful repository URL.

Adopt current organization license, naming, governance and CI/standards profile from discovered canonical sources. The new repo is a delivery/catalog/conformance owner, not the production runtime. Copy this original package under `prompts/phase1/` with a source digest and preserve its source/evidence labels. Keep archive Python helpers out of active Rust-only product tooling unless the profile explicitly admits them; packaging instructions can be stored as inert prompt assets.

Create a bounded tracking issue and link owner issues/PRs. Resolve the authenticated operator for assignment. Work on isolated branches/worktrees; do not enable auto-merge or alter protection/secrets. Implement substantive workflows/conformance/docs before claiming completion, not an empty scaffold.
