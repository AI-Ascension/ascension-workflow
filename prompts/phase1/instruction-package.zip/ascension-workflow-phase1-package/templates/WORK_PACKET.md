# Work packet — fill at dispatch

Task ID / workstream:
Parent agent ID / assigned child ID / depth:
Required model / effort: `gpt-5.6-luna` / `max`.
Actual accepted/effective settings and evidence:
Objective and observable behavior:
Repository and exact base commit:
Branch/worktree (approved local location; redact personal absolute path in exports):
Owned write paths and lease ID:
Read-only dependencies and accepted contract digests:
Required owner docs and relevant package spec sections:
Requirement IDs / acceptance IDs / fault cases:
Dependencies already accepted, with evidence:
Forbidden scope and permitted tools/actions:
Thread/spawn limit (D3 must be zero):
Token/call/time budget and no-progress rule:
Implementation deliverables and result packet path:
Exact planned validation commands and expected assertions:
Independent verifier assignment:
Definition of done:
Escalation owner and blocker conditions:

Do not dispatch with unresolved ownership or a missing required contract. A test command may be discovered from current documentation before execution; record the actual command afterward.
