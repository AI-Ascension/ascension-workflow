# Result packet — facts, not intentions

Task ID / actual agent and parent IDs / depth:
Actual model/effort evidence level:
Outcome: implemented / verification failed / blocked / partially complete.
Repository, base and candidate commit:
Changed files and scope:
Behavior implemented and public contracts affected:
Requirements satisfied, with implementation refs:
Commands actually run, exact exit codes and environment:
Test/evidence artifact paths and digests:
Independent verifier/reviewer ID and findings:
Remaining failures, risks and missing capabilities:
Actions actually taken: commit / push / issue / draft PR / assignment.
Actions not taken: merge / release / deploy / native run, unless explicitly recorded.
Unresolved external operations or unknown outcomes:
Path leases released / agents or subprocesses still owned:
Next dependency-ready task or precise blocker:

Do not place secrets, raw private model output, proprietary game data, or private chain-of-thought here. Distinguish a schema fixture pass from product runtime evidence.
