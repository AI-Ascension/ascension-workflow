# ADR-WF-NNN — Decision title

Status: proposed / accepted / superseded.
Canonical owner and reviewing owners:
Date and exact source baseline:
Requirement IDs:

## Context and observed source
Identify inspected interfaces and failure cases with exact repository/commit/path references. Separate baseline fact from proposed behavior.

## Decision
State ownership, contract semantics, compatibility/version policy, and intended implementation boundary.

## Alternatives and tradeoffs
Discuss complexity, recovery uncertainty, cost, privacy, integration, and rejected alternatives. Do not treat this ADR as permission to expand user scope.

## Invariants and failure behavior
Define what is forbidden and the exact safe behavior for unknown/timeout/stale/conflicting states.

## Validation and rollout
Name acceptance/fault cases, old/new compatibility, migration, default enabling, rollback, and native evidence gates.

## Consequences and provenance
Record affected producer/consumer artifacts, source/license/digests, open risks, and follow-up owner.
