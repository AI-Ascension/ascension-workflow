# AI-Ascension gameplay workflow management — Phase 1
## Implementation meta-prompt package • 9 September 2026

**Deliverable:** implement strict and bounded-dynamic gameplay workflow management, headlessly, across the existing AI-Ascension runtime. Create the new delivery repository **`AI-Ascension/ascension-workflow`**. Keep the production workflow interpreter, scheduler, store adapters, and management entrypoints in **`AI-Ascension/sts2-harness`**. Do not create a second gameplay runtime.

This archive contains instructions, proposed contract seeds, synthetic fixtures, task decomposition, and package-verification tools. It is **not an implemented workflow engine**, a deployment, or evidence of live gameplay. Source observations are pinned in `sources/source-register.json`; the executing agent must re-inspect current repositories before editing.

## Launch

Extract the complete archive into the coding agent's accessible workspace. Give the root orchestrator this instruction, substituting the actual extraction directory:

```text
Read <PACKAGE_DIR>/00_START_HERE.md and then execute
<PACKAGE_DIR>/01_MASTER_ORCHESTRATION_PROMPT.md in full.

Implement Phase 1 only. Create or safely resume AI-Ascension/ascension-workflow
as the delivery repository; implement the authoritative runtime in sts2-harness
and the necessary minimal changes in the existing boundary-owner repositories.

Use real Luna Max subagents at three descendant levels:
D0 root -> D1 workstream leads -> D2 work-package coordinators -> D3 specialists.
Every descendant must use gpt-5.6-luna with reasoning effort max, verified against
the actual runtime. D3 agents may not spawn. Do not silently substitute models,
flatten the hierarchy, or pretend that unsupported runtime settings took effect.

Follow the package's permissions, source refresh, isolated-worktree, integration,
validation, privacy, and evidence rules. Deliver implementation, tests, linked
draft PRs, and an accurate completion report; do not stop at scaffolding or a plan.
Do not implement Phase 2, a visual editor, a browser application, or a second scheduler.
```

The launch instruction authorizes only the bounded work described in `orchestration/03_AUTHORIZATION_GIT_AND_INTEGRATION.md`. The creation of this archive did not create a GitHub repository, launch subagents, modify source, or run a game.

## Execution order

1. Read the master prompt, scope/ownership, source refresh, hierarchy, and permission documents.
2. Verify runtime model/effort/depth capabilities and record actual evidence. Load current repository instructions and pin current heads.
3. Bootstrap the delivery repository non-destructively; establish task, requirement, evidence, and integration ledgers.
4. Freeze the versioned contracts, then implement and verify work packages in dependency order. Execute independent work concurrently within the global ceiling.
5. Integrate exact candidate revisions, run complete validation, prepare draft PRs, and report every remaining blocker without converting unavailable evidence into a pass.

## Package map

| Directory | Purpose |
|---|---|
| `spec/` | Phase-1 product and engineering requirements. |
| `orchestration/` | Three-level delegation, model checks, scope, workstreams, task graph, and handoffs. |
| `prompts/` | Reusable prompts for leads, coordinators, implementers, reviewers, continuation, and final integration. |
| `contracts/` | Proposed machine-readable seeds; production contracts must be completed and owned by the harness. |
| `examples/` | Synthetic examples and malformed-input cases; no proprietary game data. |
| `quality/` | Stable requirement IDs, acceptance coverage, fault-injection cases, and completion gates. |
| `templates/` | Work/result packets, source locks, ADRs, authorization, and reports. |
| `config/` | Inert configuration examples and orchestration policy, not auto-installed configuration. |
| `diagrams/` | Mermaid source for ownership, hierarchy, gameplay, and recovery. No UI implementation. |
| `sources/` | Primary-source register and source-derived baseline. |
| `tools/` | Offline package integrity and fixture checks; not product acceptance tests. |

## Verify this archive

From the extracted package directory, with Python 3.11 or later:

```text
python tools/verify_package.py
python -m unittest discover -s tools -p "test_*.py" -v
```

Optional schema-fixture validation uses the separately installed `jsonschema` development package:

```text
python tools/validate_artifacts.py
```

The optional tool never installs packages or contacts the network. Its absence is reported as a skipped check, not a product failure or product pass. See `BUILD_VERIFICATION.md` for the checks actually run while preparing this archive.

## The crucial distinction

**Strict** means the published control graph is fixed; an explicit decision node may still call an AI provider. **Dynamic** means a planner may propose a bounded typed DAG inside an approved adaptive region. Both modes use exactly the same authority, legality, freshness, journaling, reconciliation, and settlement kernel.

A workflow checkpoint is not a game save. An accepted request is not a settled action. A schema, green fixture, or model response is not native-host compatibility evidence.
