# Luna Max runtime preflight

## Required settings and primary sources

The requested descendant model is `gpt-5.6-luna` with reasoning effort `max`. OpenAI's model documentation identifies that model and supports `max`; the current configuration reference describes default subagent model/effort settings and the concurrent-thread setting [S13–S14]. These public docs do not prove availability or effective settings on the executing account/client.

Inspect the installed client version, actually available model catalog, current role/config schema, active mode, permission inheritance, and spawn tool schema. Do not add unsupported fields to a reserved tool call. Do not assume every Codex build implements the same keys. The sample files under `config/` are inert examples, not an instruction to overwrite global config.

## Preflight sequence

1. Record executable/client version, relevant supported configuration keys, and actual available spawn tools. Do not record secrets or complete personal config files.
2. Verify Luna and `max` availability with the supported model/config mechanism. Leave requested and observed values distinct.
3. Configure descendant defaults and each supported custom role explicitly. Preserve the parent's approval/sandbox mode. No force-unrestricted mode, no account switch, no hidden provider endpoint change.
4. Verify a small read-only D0→D1→D2→D3 delegation chain. Each child returns its runtime thread/parent identity and a bounded synthetic acknowledgement. Use tool-side configuration/metadata, not the child's prose, to attest the model.
5. Validate the lineage and record that D3 has no permitted spawning route. Do not rely on a guessed `max_depth` key; enforce the explicit packet policy and the actual supported runtime restriction.
6. Verify the global ceiling counts all descendant threads as configured. Close the preflight chain and release capacity before substantive implementation.

## Configuration adaptation

The current documented settings include `agents.default_subagent_model`, `agents.default_subagent_reasoning_effort`, and `agents.max_concurrent_threads_per_session`; `agents.max_threads` is documented as a legacy alias [S14]. Use whichever exact schema the installed supported client actually accepts, with evidence. Do not add old feature flags to make a sample parse by guesswork.

A root launched on another model can still set descendant Luna defaults when supported. If explicit child effort is omitted, model defaults/inheritance may differ; always configure and verify `max` deliberately [S14]. User words such as "Luna Max" do not automatically configure the runtime.

No speed-tier override is requested. Preserve ordinary service-tier settings; do not silently add a paid fast tier, pro mode, or a different model alias.

## Failure behavior

If Luna/Max is unavailable, do not substitute Terra, Sol, Astra, xhigh, or another account. Record the limitation. Continue safe source discovery and other preparation that does not falsely purport to satisfy the delegated implementation requirement, and deliver a resumable blocker report.

If depth three is unavailable, do not rename flat workers to D2/D3, use nested shell/API processes to evade a limit, or invent transcript evidence. A documented equivalent supported native hierarchical mechanism may be used only if it truly preserves parentage/permissions/depth and the requested model; record exactly what mechanism was used.

If model settings are accepted but not observable, label the evidence configuration-only. Do not assert unavailable metadata as verified. Implementation evidence can still be useful, but the model-attestation gate remains qualified.

## Minimal attestation

Use `orchestration/agent-attestation.schema.json`. An actual record links to sanitized tool/config evidence at an exact client version and timestamp. Templates contain null observations because no subagents were launched while building this package.
