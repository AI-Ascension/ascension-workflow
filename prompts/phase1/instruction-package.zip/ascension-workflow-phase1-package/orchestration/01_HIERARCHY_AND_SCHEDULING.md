# Actual three-level descendant orchestration

## Depth is measured below the root

D0 is the current root orchestrator. D1 workstream leads are its children. Each D1 lead spawns D2 work-package coordinators. Each D2 coordinator spawns D3 implementation, verification, or adversarial-review specialists. D3 is a leaf and must never spawn. This is four tiers including the root, with exactly three permitted descendant layers.

Every D1/D2/D3 agent uses Luna Max: `gpt-5.6-luna`, reasoning effort `max`. No specialist gets a cheaper/faster/unverified model. The root need not be Luna and must record its actual launch configuration. The requested settings concern coding orchestration, not models selected by the gameplay product.

## Responsibilities

D0 owns scope, permissions, architecture arbitration, dependencies, global thread budget, integration, GitHub delivery, and final truthfulness. It issues bounded workstreams, not dozens of uncoordinated file-edit requests.

D1 owns a workstream's contracts, decomposition, requirement coverage, risks, and integration proposal. It creates D2 coordinators only for dependency-ready work packages and checks their summaries against evidence. It does not spawn D3 leaves directly.

D2 owns one bounded work package, path leases, implementer/verifier separation, test commands, failures, and result aggregation. It gives leaf agents the minimum necessary immutable context plus exact owned files and interfaces.

D3 reads current owner instructions, executes its bounded implement/test/review task, records exact evidence, and returns a result packet. A D3 reviewer does not approve its own implementation and does not silently fix defects in a read-only review assignment.

## Width, resource admission, and deadlock prevention

The default global limit is 12 open descendant threads or the lower actual runtime limit. Count active, waiting, and parked parents when the runtime counts them. At most two D1 workstreams are active concurrently; each normally has one D2 coordinator and up to two D3 leaves, allowing space for independent review. Leads can queue additional work without spawning it.

Use the root's shared spawn-token ledger. A D1/D2 parent requests enough capacity for useful leaves before consuming the last available slot. If capacity is insufficient, queue work and close completed threads; do not fan out additional coordinators that cannot spawn leaves. A lower ceiling of three descendants still permits one D1→D2→D3 chain, with reviewers sequentially replacing closed leaves.

Depth limits and width limits are independent. Do not launch an exponential tree, spawn idle agents for cosmetic hierarchy compliance, or maintain fake agent IDs. Substantive implementation/test/review work must actually flow through the requested hierarchy.

## Ownership and conflicts

A work packet leases a bounded path set at an exact repository/base head and branch/worktree. No two write agents own the same files simultaneously. Schemas, manifests/lockfiles, shared traits, task/requirement ledgers, and integration locks have one named writer. Readers/reviewers may inspect concurrent work but report against exact commits.

Agents may propose cross-owner changes; they do not edit them until D0 assigns the proper owner and path lease. Do not fix unrelated lint, docs, or game behavior as part of the workflow task.

## Attestations

Each actual spawn records agent ID, parent ID, depth, role, work package, requested model/effort, runtime-accepted/effective model/effort, evidence location/type, permissions, write scope, and eventual result. Include a no-side-effect D1→D2→D3 preflight chain and verify D3 cannot create D4. Do not intentionally bypass a hard depth cap just to test it.

Attestation has two separate axes: requested configuration and observed/verified execution. Do not overwrite a null observed setting with the requested one. If the platform does not expose effective metadata, record configuration-only evidence and a verification limitation; do not claim effective-model proof.

## Integration

D3 results flow to D2, then D1, then D0. Each level summarizes changed contracts, exact commits, executed tests, unresolved problems, and artifact paths. D0 integrates approved commits into an isolated candidate branch, reruns affected suites, and delegates a fresh review chain for final independent verification.
