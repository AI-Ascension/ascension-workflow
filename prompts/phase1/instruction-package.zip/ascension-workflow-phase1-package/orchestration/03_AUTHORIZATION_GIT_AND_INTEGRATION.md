# Execution authority, Git hygiene, and delivery

## This prompt's bounded execution envelope

When the user launches the master implementation prompt, the delegated task includes creation or safe reuse of `AI-Ascension/ascension-workflow`, scoped changes in named existing owner repositories, deterministic/component testing, isolated worktrees/branches, bounded issues, commits, pushes, draft PRs, and assignment to the authenticated operator where supported. Runtime/connector approvals still apply; prompts cannot grant permissions the account lacks.

No repository writes were executed in preparing this archive. Repository creation occurs only when the future implementation prompt runs under available authorization.

## Allowed and separately gated work

Allowed: inspect current source and PRs, copy this user-requested original instruction package with provenance, edit admitted source/tests/docs, run local deterministic tests and bounded loopback process tests, create scoped branches/worktrees, commit explicit files, push those branches without force, create linked draft PRs, and assign issues/PRs to the authenticated operator.

Separately gated: changing organization visibility/policies, making private artifacts public, merging PRs, releases/package publication, changing branch protection/secrets/DNS, installation/deployment, host or machine restarts, game-profile mutation, live provider expenditure, valued/proprietary data access, broad external network exposure, destructive tests on non-disposable environments, and global agent configuration changes.

Coding-agent execution is the requested activity; product-time live gameplay/provider tests are a separate permission and budget boundary. Do not treat a Luna coding subscription as authorization to bill an arbitrary gameplay provider account.

## Repository bootstrap

Use the exact owner/name. Check whether it already exists and whether it is accessible. A denied request is not proof of absence. Reuse existing work without resetting, force pushing, deleting branches, or overwriting history.

If creation is supported and authorized, default a genuinely new repository to private unless the operator's explicit repository-creation policy specifies public. Do not change an existing repository's visibility. If the organization disallows the chosen visibility, report that policy blocker rather than silently publishing. This is a publication safeguard, not a reason to block all local implementation.

Use approved organization license/naming/governance templates discovered from current sources. Pin standards artifacts and record provenance. Do not copy an implementation from another repository merely because it is public.

## Worktree discipline

Inspect dirty state first. Preserve all pre-existing changes. Create one isolated worktree/branch per write package, under an approved workspace. Never run `git reset --hard`, broad `git clean`, `checkout -- .`, `git add .`, `git add -A`, force push, or branch deletion as routine cleanup.

D0 is the integration owner. D3 implementers may create narrow commits within their assigned branch; only the assigned integration actor pushes/opens PRs unless explicitly delegated. Review leaves are read-only. No agent writes another agent's leased files.

## Identity and assignment

Resolve the authenticated GitHub identity at execution time. Assign new issues and draft PRs to that operator (for example using a supported `@me` mechanism), not a guessed hard-coded username. If assignment is unsupported/denied, report it separately rather than marking it done.

Do not add forged commit signatures or claim commits are signed without a verified signature. Preserve existing signing requirements. Do not bypass CI or owner reviews because a branch is unprotected.

## PR topology

Create a delivery tracking issue in `ascension-workflow` and narrowly scoped owner issues/PRs. Link dependent PRs and exact interface/artifact revisions. Suggested order: ownership/contracts; harness strict extraction; harness durable runtime; gateway/receipt capability changes and MCP/protocol consumers as required; dynamic execution; management surfaces; workflow catalog/conformance; final documentation/evidence.

A draft PR body lists scope, requirement IDs, source base, contracts changed, commands/results, uncertainty/evidence limits, native tests not run, dependencies, and migration/rollback impact. No auto-merge. Local integration candidate commits are not represented as merged main.

## Conflicts and repair

Fetch current target refs before final integration. Resolve only feature-related conflicts, rerun exact affected suites, and keep repair commits narrow. Unrelated failing baseline checks are recorded with reproduction and ownership; do not delete tests or reduce lint to get green.

## Completion status

Report repository creation, branches, commits, pushes, PR creation, assignment, CI, merge, release, deployment, and native validation separately. A missing permission/tool may leave a step blocked; deliver remaining completed work and the exact safe resume point rather than claiming a false success.
