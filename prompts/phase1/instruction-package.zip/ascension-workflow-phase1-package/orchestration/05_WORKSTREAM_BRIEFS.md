# D1 workstream briefs

## WS-A — Discovery, ownership, and contracts

Read current owner instructions, baseline source paths, package scope, and all proposed contracts. Own source refresh, permission/model preflight records, delivery bootstrap, ADR coordination, canonical definition/plan/event/capability shapes, and requirements traceability. Delegate bounded source and schema tasks through D2. Freeze contracts before consumer implementations. Own shared schema files and contract locks until handoff.

Exit: exact source lock, accepted ownership/semantics ADRs, admitted repo bootstrap, valid positive/negative contract fixtures, and compiler contract ready for implementation. Do not call an ADR an implemented runtime.

## WS-B — Strict runtime and protected action integration

Read the complete current runner/policy/action/observation/settlement/recovery source and tests. Extract reusable operations while retaining legacy equivalence. Implement strict scheduling, typed guards, bounded loops/subworkflows, current catalog binding, non-bypassable mutation lifecycle, selection routing, and error-preserving cleanup.

Exit: actual strict synthetic episodes through the protected path, original negative tests, current-generation/identity enforcement, no provider terminal calls, and differential legacy parity.

## WS-C — Store, authority, and recovery

Own real local store adapter, persistent events/materialized state, transactional effect intent, budget persistence, restart classification, pending effect recovery, and cross-boundary authority prerequisites. D2 packages must keep gateway/MCP/mod changes in their correct owners. Read current watchdog and gateway limitations; do not assume a durable harness cursor solves them.

Exit: real-process restart/fault tests, stale-owner fencing, original-operation receipt reconciliation, explicit unsupported failure domains, and no fresh mutation while uncertainty persists.

## WS-D — Dynamic planning and provider/context integration

Own typed planner port, admitted registry, bounded DAG validation/execution, registered subworkflow selection, immutable context manifests, provider budgeting, plan revision/invalidation, bounded parallel pure analyses, and privacy-approved structured outputs.

Exit: at least two distinct controlled plan topologies, strict rejection of forbidden mutation/script/policy nodes, old-result rejection, durable plans/budgets, and offline reproducibility without private chain-of-thought.

## WS-E — Headless operations and observability

Own actual CLI/API adapter, command idempotency/revision checks, authenticated loopback control, pause/resume/step/cancel, status/event export, bounded client behavior, telemetry projection, and offline workflow replay. Read-only/validate/replay operations cannot construct mutating ports.

Exit: executable CLI/API process tests, command/reconnect/auth/failure tests, privacy redaction, store-backed status after restart, replay with zero provider/game calls, and no browser code.

## WS-F — Catalog and cross-repository integration

Own first-party STS2 strict/dynamic workflows, synthetic stage episodes, optional map/expert capability gating, artifact consumption, conformance driver, integration locks, and dependency-aware delivery tracking. Actual game effects always remain in the harness protected path.

Exit: catalog compiles and executes through the built harness in synthetic profiles, unsupported native capabilities are explicit, and copied artifacts match their producing candidate heads/digests.

## WS-G — Independent verification, security, and delivery

Use separate D2→D3 reviewer/verifier chains. Own original adversarial tests, fault matrix execution, full integrated regression, performance observations, current-head CI repair verification, and release-readiness report. Reviewers must not merely repeat implementer claims.

Exit: every mandatory requirement has executed evidence or an explicit justified blocker, no outstanding P0/P1 defects for a completion claim, linked draft PRs, safe operating/migration/rollback docs, precise model/depth compliance, and no unsupported native/deployment claim.
