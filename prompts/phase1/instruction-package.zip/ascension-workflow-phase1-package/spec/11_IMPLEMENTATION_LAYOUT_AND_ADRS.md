# 11 — Implementation layout and decisions

## New delivery repository

```text
ascension-workflow/
  README.md                    # Actual status, scope and entrypoints
  AGENTS.md                    # Owner-specific contributor contract
  LICENSE                      # Admitted organization license
  docs/{architecture,operations,decisions,evidence}/
  workflows/sts2/               # Substantive first-party definitions
  contract-artifact/workflow-v1/# Pinned harness-exported inert contract
  conformance/                 # Golden, invalid and cross-boundary cases
  integration/                 # Exact-head lock and process driver configuration
  tools/                       # Only admitted standards-profile implementations
  prompts/phase1/              # This package, provenance-preserving
  quality/                     # Live requirement and verification ledger
```

Choose the current applicable standards profile rather than imposing a language by convenience. A Rust conformance driver is preferred if executable tooling is needed. It invokes the built harness process or consumes public artifact data; it does not implement graph execution or link sibling source paths. Do not add an empty crate merely to look implemented.

## Harness-owned modules

Start under the existing package, subject to current layout policy:

```text
crates/harness/src/workflow/
  definition.rs / validation.rs / compilation.rs
  scheduler.rs / strict.rs / dynamic.rs
  node_registry.rs / guards.rs / budgets.rs
  journal.rs / recovery.rs / events.rs / management.rs
```

Keep file budgets by splitting cohesive responsibilities, not arbitrary numbered files. Storage, HTTP, CLI, provider and runtime adapters belong in owner-admitted adapter/binary modules. A separate package inside the harness repository requires a concrete boundary benefit and current policy admission; do not create a new shared implementation repository.

Canonical schemas/conformance live under harness-owned paths and are exported as a release-like data artifact. Pure runtime tests, adapter tests, process tests, and fault tests use different suites so their evidence is not conflated.

## Mandatory ADR topics

ADR-WF-001: repository ownership and one authoritative runtime.
ADR-WF-002: workflow/control/data graph semantics, typed guards, canonicalization, and immutable revisions.
ADR-WF-003: protected action transaction, identity namespaces, and compatibility with legacy runner.
ADR-WF-004: durable store, transactional boundaries, crash classification, retention, and failure model.
ADR-WF-005: authority/fencing/receipt capabilities and supported recovery failure domains.
ADR-WF-006: adaptive regions, typed planning registry, budgets, and plan invalidation.
ADR-WF-007: headless API/CLI commands, authentication, optimistic concurrency, and event delivery.
ADR-WF-008: fair-play context, structured artifact retention, offline replay, and telemetry boundaries.
ADR-WF-009: first-party workflow catalog, capability gates, evidence profiles, and rollout/rollback.

Decisions include alternatives, chosen contract, compatibility effects, failure cases, evidence needed, and owner. An ADR describing a feature is not implementation evidence.

## Change integration

Contracts merge into local integration candidates before implementations depend on them; public API changes require consuming tests. Gateway/MCP/protocol/mod work is minimal and owned. Record exact compatible candidate heads/artifact digests in an integration lock; do not claim an unmerged candidate is present on main.

Preserve a feature-flagged legacy path until strict parity and migration tests pass. Default enabling policy is an explicit release decision, not an incidental constructor change. Rollback may disable new workflow admissions while retaining journals and recovery visibility; it may not delete uncertain operations or downgrade a newer store destructively.
