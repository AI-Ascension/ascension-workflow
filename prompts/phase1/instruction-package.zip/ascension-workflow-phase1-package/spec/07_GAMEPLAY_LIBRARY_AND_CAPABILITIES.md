# 07 — First-party gameplay workflow catalog and capability admission

## Deliver actual reusable workflows

Publish digest-pinned, compiler-valid workflow definitions in the new delivery repository, consuming accepted harness contracts. Provide a complete synthetic campaign fixture and stage-specific cases. No proprietary game files, actual saves, hidden state, or copied game rules belong in the catalog.

Required catalog entries:

| Workflow | Required behavior |
|---|---|
| `sts2.campaign.strict` | Validate run admission; observe; route by authoritative coarse stage; bounded loop; terminal observation and cleanup. |
| `sts2.setup.strict` | Use only exposed setup actions and validated parameters; no guessed host sequence. |
| `sts2.combat.strict` | Fixed observation/decision/protected-execution loop; provider failure is explicit. |
| `sts2.combat.dynamic` | Approved adaptive analysis DAG or subworkflow selection; one proposal returned to fixed execution path. |
| `sts2.map.strict` | Choose from current legal map actions with the baseline visible observation. |
| `sts2.map.dynamic` | Richer analysis only with admitted map capability, generation-bound projection, and matching action catalog. |
| `sts2.reward.strict` | Inspect visible offers and current legal actions, choose or skip only when legal. |
| `sts2.shop.strict` | Observe resource/offer data actually available; one purchase/proceed action at a time, bounded existing plan reuse if admitted. |
| `sts2.event.strict` | Choose among visible options; no invented outcomes or hidden event branches. |
| `sts2.rest.strict` | Choose a currently exposed legal rest-site action; update dependent planning only after settlement. |
| `sts2.selection.strict` | Handle a supported authoritative selection state, preserve parent stack, return only on a verified supported state. |
| `sts2.recovery.strict` | Bounded reobserve/reconcile; stop or needs-operator for unknown authority/effects. |
| `sts2.terminal.strict` | Record victory/defeat observation, separate workflow result, stop admissions, and clean up. |

If a current host lacks a required stage/action capability, implement the generic route and synthetic test, mark native stage support unavailable, and do not fabricate gameplay evidence. Source/component completion and native coverage are separate gates.

## Capabilities, not guessed build support

Negotiate or inspect a manifest with producer identity, runtime profile, schema/artifact digests, freshness/identity requirements, supported observation fields, action catalog kinds, operation/receipt semantics, and evidence scope. A manifest saying a field is supported is not proof that a specific response contains a current valid value.

Required capabilities fail admission; optional capabilities select an explicitly authored fallback. Unknown versions, mismatched digests, stale projections, missing required fields, and undeclared hidden fields must be rejected or filtered at the owner boundary. The planner cannot elevate a capability from optional to supported by asserting it exists.

Runtime-v3 baseline paths, runtime-v4 expert additions, runtime-map-v1, and coordinator-reported co-op are independent profiles with different evidence [S07–S11]. Do not treat co-op coordinator metadata as native multiplayer actuation. Native multiplayer gameplay is excluded.

## Fair-play and context

Only observations admitted by the fair-play boundary enter gameplay decisions. Visible-seed forwarding follows the configured experiment policy; never reconstruct hidden RNG or unrevealed rewards from privileged data. A visible map graph is navigation information, not the workflow graph.

For every decision/analyze/planner node, define a context manifest: observation fields, current legal actions, objective revision, immutable policy constraints, relevant approved prior artifacts, prompt version, max bytes/tokens, retention policy, and capability dependencies. Do not feed the entire journal or every source document into every model call.

Missing state stays unknown. Workflow authors cannot declare unobserved enemy behavior or reward outcomes as fact. Any strategy heuristic is a separately named decision adapter with tests, not authoritative game semantics hidden in the scheduler.

## Bounded nested transitions

Support selection interrupts, combat end into reward, reward into map, and setup into a campaign only where authoritative observations/fixtures demonstrate the transition. Never assume an action implies a stage change. Route using verified post-action observations. Ensure the parent cursor is durable across selection subworkflow entry/return.

## Evidence suite

Provide seeded synthetic episodes covering all coarse stages including unknown/recovery/terminal; assert no provider calls at terminal; no mutation while input blocked; current-catalog revalidation after every effect; plan invalidation on relevant changes; graceful capability absence; and complete workflow outcome records.

Native tests run only in explicitly authorized disposable profiles. Record exact game/mod/gateway/MCP/harness/contract/workflow/provider versions, seed policy, actions, settled witnesses, unresolved operations, and cleanup. A forced victory observation is not a model-played victory; a losing campaign can still validate safe orchestration for its exercised path.
