# 10 — Validation, evidence, and completion gates

## Required evidence levels

G0: repository/source discovery and exact locks. G1: schema/compiler and pure reducer tests. G2: actual CLI/API/provider-fake/runtime-fake process integration. G3: real transactional-store restart and fault-injection tests. G4: cross-repository authority/reconciliation contract conformance at exact candidate heads. G5: explicitly authorized native-game checks. G6: independent final integration and delivery review.

G1–G4 must be implemented and exercised for source/component completion. G5 is required for any native compatibility or unattended live-recovery claim; if authorization/environment is missing, retain a blocked native gate while completing safe implementation. G6 reports partial versus complete scope honestly.

## Baseline commands

Discover and run each owner's actual current documented commands. The harness baseline includes:

```text
cargo run --locked --package repo-policy -- --strict
cargo fmt --all --check
cargo clippy --workspace --all-targets --all-features --locked -- -D warnings
cargo test --workspace --all-targets --all-features --locked
```

Also verify copied artifact bytes/checksums, workflow catalog compilation, synthetic end-to-end episodes, API/CLI process behavior, durability adapter tests, negative plan cases, redaction, and replay. Run changed-repository suites, not only a newly added happy-path unit test. Re-run on the final integrated candidate revisions.

The archive's Python tools are not product evidence. A successful build is not proof of runtime effects; successful native observation is not proof of action settlement or a winning strategy.

## Acceptance categories

Compiler: strict schemas, duplicate-key rejection, types, guards, bounds, graph reachability, loops, dependency cycles, capabilities, canonical digest, immutable versions.

Strict runtime: old/new equivalence, no provider at terminal, current legal actions, machine-enforced constraints, unavailable routes, selection interrupts, complete protected stepping.

Dynamic runtime: actual topology variation, approved subworkflow selection, DAG composition, no mutation nodes in plans, bounded parallel analysis, stale/revision rejection, plan invalidation, budgets, offline replay.

Durability: each crash window, intent-before-send, unknown outcomes, no blind retry, operation receipt identity, expired receipts, changed epochs, simultaneous writers, database corruption/disk failure, preserved primary and cleanup errors.

Management: process tests, auth scopes, no side effects on read/validate/replay, duplicate/conflicting commands, optimistic concurrency, pause/cancel while pending, event pagination/reconnect/gap, bounded clients.

Privacy/authority: malicious text, schema smuggling, arbitrary script/path/provider injection, secret export, cross-run/cross-instance data, hidden-state access, permission escalation, registry and definition tampering.

## Differential and adversarial tests

Build deterministic normalized observation/decision fixtures for the legacy runner and new strict engine. Compare mutation ordering, operation semantics, recovery actions, terminal interpretation, and cleanup. Accept intended differences only via an ADR and explicit regression cases.

Use fault injection against a real store and real control-plane processes, with synthetic game/provider adapters. Reviewers add original negative tests not written by the implementing leaf. Mutation counts and identities must be observed at the effect-owning fake boundary, not inferred from scheduler counters alone.

## Requirement traceability

`quality/requirements.json` is the minimum baseline. Every requirement has an owner, test IDs, status, implementation refs, and evidence refs in the executing project's live matrix. `orchestration/tasks.json` maps implementation packages to those IDs. Do not set requirements complete because a file exists or because a task was delegated.

No P0/P1 correctness, recovery, authorization, or privacy defect may remain open in a source/component-complete claim. Lower-priority issues must be documented, scoped, and not conflict with mandatory requirements.

## Delivery gates

The final delivery has functional code, actual workflow catalog, tested CLI/API, durable adapter, strict/dynamic/replay fixtures, process/fault tests, migration/recovery/security docs, exact-head integration lock, source/contract provenance, and independent review. All issues/PRs are linked and assigned to the authenticated operator where supported.

Report separately: archive integrity, implementation, test evidence, orchestration compliance, GitHub publication/merge status, deployment, native compatibility, and unattended-recovery support. No merge, release, installation, or deployment happens without the separate authorization in the execution envelope.
