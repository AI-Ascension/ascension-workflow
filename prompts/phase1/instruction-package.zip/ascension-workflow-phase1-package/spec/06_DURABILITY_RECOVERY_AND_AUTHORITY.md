# 06 — Durability, restart admission, and authority

## Storage adapter

Implement `WorkflowStorePort` plus a real local transactional adapter, preferably SQLite on a local filesystem. Keep SQL/storage implementation outside the pure scheduling core. SQLite WAL is a proposal, not a project dependency already installed. Select and pin a maintained compatible Rust binding and SQLite version after current security/compatibility review. Official documentation notes WAL's local-host filesystem constraint and the durability difference between NORMAL and FULL synchronization [S15–S16].

For the proposed WAL adapter, require and verify effective `journal_mode=WAL`, `synchronous=FULL`, foreign-key enforcement, bounded busy timeouts, migrations, and a local supported filesystem. Do not claim power-loss durability beyond the filesystem/OS/hardware assumptions. A network-share database is not a supported WAL deployment.

Persist definitions/compiled artifacts, runs, node invocations, immutable events, current materialized state, loop/stack counters, plans/revisions, budget reservations/usage, provider intents, game-operation intents/receipts, ownership/recovery tokens, and typed replay artifacts. Define uniqueness constraints for run/event sequence, invocation, command identity, and operation identity.

## Atomic local state

A transaction must atomically reserve a pending mutation, persist its immutable payload digest/identity, and record intent before sending. A later transaction atomically records verified settlement, advances the cursor, updates counters, and clears the pending slot. Never keep a transaction open while waiting on provider, network, or game work.

Use expected run revision/compare-and-swap for commands and scheduler transitions. A process-local mutex is insufficient when two harness processes can target the same run/instance. Implement supported single-writer/run ownership and downstream fencing; stale local owners must fail authoritative dispatch even after pauses or crashes.

JSONL exports are derived evidence, not the only source of atomic recovery state. Export interruption cannot roll back durable run state. Corrupt or missing journals/artifacts are quarantined and surfaced; never silently reset to an empty ledger.

## Recovery classification

| Persisted state | Safe next step |
|---|---|
| No external-effect intent | Resume pure scheduling from the last committed revision. |
| Intent persisted but no reliable proof of unsent status | Treat external dispatch as possibly sent; reconcile or use an owner-supported same-identity deduplication contract. Absence of a sent event is not proof of no send. |
| Provider request uncertain | Reconcile if supported; otherwise policy-controlled retry with cost uncertainty, or block. |
| Game request uncertain | Reconcile original operation; never replace its identity. |
| Receipt says accepted | Await/reconcile authoritative settlement; do not advance. |
| Verified settlement persisted, cursor not advanced | Transaction design should prevent this split; recover by idempotent completion with validated receipt if migrating legacy state. |
| Receipt expired, missing, conflicting, or from another instance/epoch | `NeedsOperator`, pending effect retained. |
| Gateway/host boot identity changed | Perform explicit owner-supported recovery handoff or `NeedsOperator`; never assume old credentials/epochs remain valid. |
| Store unavailable/disk full/read-only/corrupt | Close new admissions; preserve already-pending effects in recovery reporting; do not dispatch unjournaled work. |

The critical ambiguity is between commit of intent and commit of a send marker. A crash can occur immediately after the network send and before any local send marker. The design must handle that interval as uncertain.

## Authoritative prerequisites

The attached baseline gateway lacks documented lease TTL/renewal and durable boot-epoch rotation [S07]. Do not paper over this in the harness. Audit gateway instance/lease identity, restart fencing, ownership acquisition, receipt retention, and the host-side effect ledger as one cross-boundary contract.

Implement the minimum typed additions necessary to expose:
- whether safe same-instance continuation is supported;
- current durable boot/fencing identity and valid ownership binding;
- original operation reconciliation with retained immutable payload identity;
- retention scope/lifetime and explicit expired/unknown outcomes;
- a recovery-only lookup/handoff path that cannot gain new mutation permission merely by knowing an old operation ID.

If gateway claims retention but the host loses authoritative receipts after reboot, classify host-restart recovery unsupported. Do not use a new game observation to guess which of several pending actions happened. Gate automatic restart separately for harness-only, gateway, host, and machine-reboot failure domains.

## Watchdog contract

Watchdog reads typed health/progress/recovery-admission status through a declared control interface. It may restart only under its own authorized supervision policy; it never chooses an action or advances the workflow. Recovery admission reports: no pending effects, reconciling, safely resumable under named capability, needs operator, or terminal with verified cleanup.

Separate alive/readiness/progress: a healthy process blocked on unresolved mutation is not safely progressing. Do not restart repeatedly merely because a valid bounded provider/game wait has not finished. Recovery retries have attempt/time budgets and no-progress detection.

## Pause/cancel and cleanup

`Pausing` and `Cancelling` are durable states. Admission closure is immediate; reconciliation is not cancelled merely because the caller disconnects. Expose unresolved effects in status and final reports. Release of a lease is not proof an action did not happen. Preserve recoverable identity/history before handing authority back.

## Migrations and retention

Version the store independently of workflow schema. Migrations require backup, integrity checks, forward compatibility tests, and explicit rollback behavior. Never auto-downgrade or truncate unknown newer records. Use supported snapshot/backup procedures rather than copying a live database file without its transactional context.

Define retention separately for user-authorized structured decision artifacts, immutable audit metadata, and operation receipts. Expiring an authoritative receipt must not silently authorize a retry. Redaction/deletion can make replay unavailable; record that limitation without retaining disallowed raw content.

## Acceptance

Run a child process against the actual store adapter, kill/restart at every persisted transition and each external-effect boundary, and assert recovery outcomes. Test simultaneous writers, stale owners, receipt expiry, corruption, disk failure, schema mismatch, clock behavior across reboot, and unavailable downstreams. Mock-only store tests do not close this requirement.
