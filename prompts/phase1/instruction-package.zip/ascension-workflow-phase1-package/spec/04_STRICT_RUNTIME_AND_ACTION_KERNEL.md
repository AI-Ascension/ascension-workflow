# 04 — Strict execution and the protected gameplay kernel

## Reuse, do not fork

Refactor current `EpisodeRunner` operations into reusable harness-owned execution interfaces while retaining the old path for differential fixtures [S02–S05]. Preserve actionability, freshness, admission identity, settlement, and owner-controlled cleanup. Avoid a second loop with subtly different error handling.

Keep workflow state, game state, plan state, and pending effect state distinct. The scheduler can await a game observation, but cannot overwrite an unresolved mutation by assigning itself a Ready state.

## Deterministic execution

Use a pure reducer `current_state + recorded_event -> next_state + typed_effect_intents` or an equivalently testable state transition model. Inject clock/ID/budget/provider/store/runtime ports. External effects are executed by owned adapters; their normalized results return as events. Replay injects recorded results, not live providers.

Use stable node scheduling order when multiple pure tasks become ready. Asynchronous analysis completion must not create an accidental race-winner policy. A join emits outputs in declared order after all required results or an explicit bounded quorum policy. V1 defaults to all-required-results.

A strict graph can contain an AI decision; it cannot be rewritten at runtime. No undocumented rule-based fallback when a provider fails. A fallback is a separately authored, policy-admitted branch and a visible event.

## Action transaction

For each action proposal:

1. Verify active workflow ownership, expected run revision, no cancellation/pause admission block, and no unresolved action for the instance.
2. Read/validate authoritative capability and identity binding: instance, gateway session, lease, authority epoch, game identity, runtime profile.
3. Obtain actionable fair-play observation and matching legal catalog. Bind the proposal to state ID/generation and source context. Reject stale provider results.
4. Apply machine-enforced hard constraints. A model's confidence or rationale does not waive a rule. Select exactly one current catalog action; do not manufacture payloads or guess equivalent action IDs.
5. Allocate a durable node invocation and stable operation identity, binding immutable action payload/digest and original expected generation. Atomically persist intent and mark the instance as having one pending mutation. No external dispatch before commit succeeds.
6. Dispatch only through the existing MCP/gateway route. Authoritative downstream fences must re-check the request. Do not hold a database transaction or application lock across network/provider calls.
7. Persist receipt classification and all required identity bindings. `accepted` is not completion; `unknown` remains pending; rejection/cancellation requires the contract's explicit no-effect/settled classification.
8. Reconcile uncertain results using the original operation. Await a fresh, correlated post-action observation and the required independent effect witness. A later generation alone is insufficient proof that this action caused the change.
9. Atomically record verified completion, advance workflow state, update budgets/counters, and clear the pending mutation slot. Notify the decision source exactly once for that node invocation.

Idempotency is operation-scoped, not node-name-scoped. Repeated execution of a loop node needs a new invocation ID; a retry of the same admitted external operation must not create a fresh identity. Scope identities to run/episode/instance/authority as required by boundary contracts. Do not reuse the baseline generation/step naming without a collision analysis.

## Receipt validation

Check operation ID, instance, session, authority epoch, action payload identity, before generation, after generation, and effect witness against the original dispatch contract. An observation returned by a different operation does not settle this one. For generic runtime profiles that cannot provide required evidence, reject recovery admission or return `NeedsOperator`.

## Waits and interrupts

Use deterministic injected waits in tests. Production polling has deadlines/backoff/jitter policy and no model calls to decide whether a timeout elapsed. Unknown stage and unavailable catalog use explicit bounded recovery.

Selection interrupts may suspend a parent subworkflow only after an authoritative supported selection observation. A `modal_blocking` state is not permission to click through. Never run a selection action while a previous mutation remains uncertain.

## Stop, pause, step, cleanup

Pause persists admission closure first; pending reconciliation continues. Step executes one safe semantic unit, including the whole protected action lifecycle when the selected node mutates the game. Report stepping, waiting, or needs-operator states instead of pretending the action was instantaneous.

Cancel/stop closes new admissions, cancels cancellable pure/provider tasks, reconciles outstanding mutations, and performs owned cleanup. Cancellation cannot undo a game action. A run with unknown effects cannot be reported safely cancelled. Preserve the main error plus cleanup errors and pending operation identity; do not overwrite the causal failure with a generic shutdown error.

## Concurrency

Allow bounded read-only analyses against one immutable observation. Reject stale outputs at joins/dispatch. Admit no parallel mutating subgraphs for one game instance, even across two workflow runs or two control clients. Distinct authorized instances may execute independently, with shared global provider/storage budgets and no shared mutable game context.

## Acceptance

Prove old/new strict behavior equivalence on exact normalized observations and decisions, including rejection, recovery, catalog refresh, no-provider terminal states, interruption, and cleanup failures. Instrument mutation calls and assert zero duplicate effects in the supported fault model. Document that passing finite tests is not a universal exactly-once theorem.
