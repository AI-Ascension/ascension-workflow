# 02 — Source baseline and mandatory discovery

## Source-derived starting point, not current-head certification

The harness main head was rechecked during package preparation: `fc44d3ef65fefa6d13ecd5f690e5335a6ef60080` [S01]. Relevant seams:

| Path under `sts2-harness` | Observed seam | Required discovery |
|---|---|---|
| `crates/harness/src/episode/runner.rs` | `EpisodeRunner`, bounded configuration, runtime port, cleanup. | Public compatibility and all construction sites. |
| `episode/runner_impl.rs` | Per-run in-memory episode machine and action ledger. | Store insertion, resume semantics, legacy equivalence. |
| `episode/runner_steps.rs` | Observe, catalog refresh, policy choice, waits/recovery. | Which steps can be extracted without altering action readiness. |
| `episode/runner_actions.rs` | Intent identity, ledger admission, dispatch, receipt handling/reconciliation. | Correlation checks, pending-operation visibility, error preservation. |
| `episode/state_machine.rs` | Coordinator phases and generation checks. | Prevent graph control from overwriting a pending transition. |
| `episode/policy_router.rs` | Provider-neutral `DecisionSource`, `PolicyRouter`, string hard constraints. | Add machine-enforced policy; do not rely on prompt strings. |
| `episode/action_plan.rs` | Up to eight initially legal IDs; settlement and compatibility checks. | Keep gameplay action sequencing distinct from adaptive workflow plans. |
| `episode/observation.rs` | Setup/map/combat/reward/shop/event/rest/selection/victory/defeat/recovery/unknown; actionability firewall. | Stage classification and modal/selection behavior for each runtime profile. |
| `episode/recovery.rs`, `postconditions.rs`, `idempotency.rs`, `stability_barrier.rs` | Recovery/settlement interfaces referenced by runner. | Read current full source before designing the durable adapter. |
| `exo*`, `records.rs`, `decision_records.rs`, `replay.rs`, runtime binaries/support modules | Provider transport, privacy, records, actual process integration. | Actual fixture and runtime compatibility; avoid parallel port invention. |

The inspected source includes a 4,096-step runner cap, provider action plans of at most eight actions, and fresh-catalog binding. These are bounded current mechanisms, not proof of general workflow management. Preserve them initially or explicitly revise with compatibility tests [S02–S05].

## Existing capability cautions

Gateway documentation records no lease TTL/renewal or durable boot-epoch rotation in the attached runtime baseline. Watchdog documentation does not establish deployed live-host recovery. Runtime-v4 expert, map, and co-op source/component capabilities have more limited evidence than the named runtime-v3 campaigns [S07–S11]. Re-read exact current evidence before claiming the situation is unchanged or repaired.

The map visualizer default branch previously held bootstrap material. Its existence is not evidence of a usable visual component, and it is outside this task.

## Discovery output

Before writes, produce `docs/discovery/BASELINE.md` and a source lock in the new repository. Record repository ID, owner/name, visibility, default branch, exact commit, relevant current files, artifact profiles/digests, toolchains, license, existing local work, relevant open PRs, and the actual API capabilities observed. Never include auth tokens or personal absolute paths.

Inspect organization naming and standards through the actual repository tree. A guessed `.github/standards/repositories.yaml` path returned not found during preparation; it is not a validated canonical path. Follow the current `AGENTS.md` and discover the registry instead of creating one in a guessed location.

Read complete relevant source and tests, not only search snippets. Check whether workflow management or overlapping recovery work already exists. Reuse compatible work; do not duplicate it because this package predates a merge. Capture conflicts/dependencies in an integration issue.

## Live claims and evidence labels

Use `confirmed`, `source-derived`, `inferred`, `proposed`, `unverified`, and `unsupported` with a scope, source head, environment, and date. `confirmed` always names the exact controlled assertion, never the entire product by association. Record a failed or unavailable command separately from a negative behavior result.

The source register provides URLs and original synthesis only. Do not vendor proprietary files, code from unrelated reference implementations, credentials, private model transcripts, or full external documents into the implementation repository.

## Standards

The inspected harness standards pin Rust 1.97.1/edition 2024, rustfmt width 100, strict Clippy, explicit typed ports/errors, and nonblank file limits (production Rust preferred 300/hard 400, tests 400/600, workflow files 160/200, Markdown 500/700) [S06]. Re-read current files and toolchain before execution; these are baseline observations, not permission to downgrade or override a newer pin.

Package Python utilities are offline archive checks. They do not authorize adding Python product code to a Rust-only repository.
