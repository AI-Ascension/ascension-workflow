# 01 — Scope, ownership, and exclusions

## Product decision

Phase 1 is a headless gameplay workflow product. `AI-Ascension/ascension-workflow` is the new delivery/catalog/conformance repository. `sts2-harness` remains the owner of workflow interpretation, orchestration policy, store adapters, management API/CLI, records, and provider integration. This resolves the request for a new repository without contradicting the existing harness ownership boundary [S01–S06].

There must be exactly one canonical implementation of graph semantics and gameplay scheduling. The new repository consumes pinned harness-owned contract artifacts and drives the built harness CLI through declared process/API contracts. It must not depend on sibling source paths or import implementation internals.

## Responsibility matrix

| Owner | Required Phase-1 work | Must not acquire |
|---|---|---|
| `ascension-workflow` | First-party workflow catalog, conformance cases, orchestration package, integration/source locks, evidence, operating docs, admitted test driver. | Scheduler, game-action dispatcher, provider authority, duplicated canonical schemas. |
| `sts2-harness` | Canonical workflow/plan/event/capability contracts; compiler; strict/dynamic execution; action-kernel integration; local store; CLI/API; replay. | Direct host access, game rules, lease ownership, arbitrary MCP framing shortcuts. |
| `sts2-gateway` | Minimum authoritative restart/fencing/reconciliation support and capability disclosure required by workflow recovery. | Workflow graph execution or gameplay choices. |
| `sts2-mcp-server` | Explicit approved mapping/projection changes only. | Workflow engine, lease policy, or direct host path. |
| `sts2-protocol` | Only genuinely shared neutral artifact additions with real consumer admission. | Harness-specific scheduler policy, persistence, or a generic common crate. |
| `sts2-game-mod` | Authoritative observation/action/receipt capability and scoped persistence needed for safe recovery, where admitted. | Experiment coordination or model execution. |
| `sts2-game-core` | Domain invariants only when a concrete domain change is required. | Workflow or transport code. |
| `ascension-watchdog` | Recovery-admission/status consumption through a declared control contract. | Workflow cursor ownership, provider calls, gameplay action choice, blind restart/resend. |
| `ai-agent-observability` | Bounded telemetry field/export configuration when required. | Durable scheduler authority or synchronous requirement for safe dispatch. |
| `.github` | Optional owner-approved repository/standards registry addition if an actual current registry requires it. | Organization-wide unrelated policy or branding overhaul. |

Do not edit `ascension-map-visualizer` or create `ascension-workflow-studio`. Read-only discovery of relevant map capabilities is permitted; visual implementation is not.

## Minimum included product

Fixed strict graphs with explicit AI decision nodes; bounded dynamic plans; typed guards; bounded loops/subworkflows; capability admission; protected action execution; durable run management; exact revision pinning; headless operations; event streaming/pagination; offline replay; first-party workflow library; deterministic, adversarial, process, and permitted native tests.

Dynamic mode must include typed DAG composition for analysis/decision work, not merely a model selecting the next action while the graph remains unchanged. The fixed outer graph owns execute-action nodes. Adaptive region outputs are proposals only.

## Explicit exclusions

No visual authoring, web/browser code, desktop GUI, art, hosting, multiplayer authority implementation, full game simulation, arbitrary script execution, self-modifying runtime source, automatic host rollback, training platform, generic distributed orchestration framework, or new cloud service. No all-games abstraction campaign: provide an explicit capability adapter surface and first-party STS2 support, not an unbounded plugin ecosystem.

Live hot migration of running definitions is excluded in v1. New versions apply to new runs; existing runs remain pinned. Safe-point objective updates may be supported only through the defined management command, invalidate dependent plans, and cannot widen hard policy.

## Headless durability limits

Implement software support for safe crash classification and recoverable authority/receipt contracts. A supported configuration may automatically resume only when those capabilities are actually available and tested. An unsupported attached host must stop in `NeedsOperator` rather than claiming transparent recovery. Missing native permission is an evidence gate, not permission to omit the deterministic implementation.

## Authority of this package

All file paths, APIs, limits, schemas, and node catalogs proposed here are initial design inputs. Any change preserving the requirements needs an ADR and updated traceability. Removing scope, weakening safety, moving authority, changing the requested model/depth, or implementing Phase 2 requires new user authorization; an ADR alone is not enough.
