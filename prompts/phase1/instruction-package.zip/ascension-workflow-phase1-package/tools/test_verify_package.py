"""Package-tool regression tests. These are not gameplay acceptance tests."""
from __future__ import annotations
import json
import tempfile
import unittest
from pathlib import Path
from verify_package import dependency_errors, load_json, safe_relative, traceability_errors, verify
from validate_artifacts import seed_semantic_errors

ROOT = Path(__file__).resolve().parents[1]


class PackageTests(unittest.TestCase):
    def test_distributed_package_is_valid(self) -> None:
        self.assertEqual(verify(ROOT), [])

    def test_traceability_is_complete(self) -> None:
        self.assertEqual(traceability_errors(ROOT), [])

    def test_unsafe_paths_rejected(self) -> None:
        for path in ("../escape", "/absolute", "C:/drive", "a\\b", "a/../b", "a//b", ""):
            self.assertFalse(safe_relative(path), path)
        self.assertTrue(safe_relative("spec/example.md"))

    def test_duplicate_json_keys_rejected(self) -> None:
        with self.assertRaises(ValueError):
            load_json(ROOT / "examples/invalid/duplicate-keys.json.txt")

    def test_nonfinite_json_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "bad.json"
            path.write_text('{"value": NaN}', encoding="utf-8")
            with self.assertRaises(ValueError):
                load_json(path)

    def test_task_cycle_detected(self) -> None:
        rows = [{"id": "A", "dependencies": ["B"]}, {"id": "B", "dependencies": ["A"]}]
        self.assertTrue(dependency_errors(rows))

    def test_unknown_task_dependency_detected(self) -> None:
        self.assertTrue(dependency_errors([{"id": "A", "dependencies": ["missing"]}]))

    def test_unbounded_workflow_cycle_rejected(self) -> None:
        data = load_json(ROOT / "examples/invalid/workflow-unbounded-cycle.json")
        self.assertIn("Unbounded graph cycle", seed_semantic_errors(data))

    def test_pending_operation_not_safely_terminal(self) -> None:
        data = load_json(ROOT / "examples/runs/needs-operator.json")
        self.assertEqual(seed_semantic_errors(data), [])
        data["status"] = "completed"
        self.assertTrue(seed_semantic_errors(data))

    def test_positive_workflow_and_plan_seeds(self) -> None:
        for path in ("examples/workflows/strict-fixture.json", "examples/workflows/dynamic-fixture.json",
                     "examples/plans/valid-plan.json", "examples/plans/valid-simple-plan.json"):
            self.assertEqual(seed_semantic_errors(load_json(ROOT / path)), [], path)

    def test_missing_manifest_is_failure(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            self.assertTrue(verify(Path(directory)))

    def test_minimal_tampered_payload_is_detected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / "payload.md").write_text("tampered\n", encoding="utf-8")
            manifest = {"files": [{"path": "payload.md", "bytes": 1, "sha256": "0" * 64}],
                        "payload_file_count": 1, "total_distributed_files": 3}
            (root / "PACKAGE_MANIFEST.json").write_text(json.dumps(manifest), encoding="utf-8")
            (root / "SHA256SUMS").write_text("", encoding="utf-8")
            self.assertTrue(any("integrity mismatch" in error for error in verify(root)))


if __name__ == "__main__":
    unittest.main()
