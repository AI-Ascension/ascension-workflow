#!/usr/bin/env python3
"""Offline integrity/traceability checks for this instruction archive, not product tests."""
from __future__ import annotations
import argparse
import hashlib
import json
import re
import sys
import tomllib
from pathlib import Path, PurePosixPath
from typing import Any

MAX_JSON_BYTES = 8 * 1024 * 1024


def reject_constant(value: str) -> None:
    raise ValueError(f"Non-finite JSON value: {value}")


def unique_pairs(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"Duplicate JSON key: {key}")
        result[key] = value
    return result


def load_json(path: Path) -> Any:
    raw = path.read_bytes()
    if len(raw) > MAX_JSON_BYTES:
        raise ValueError(f"Oversized package JSON: {path.name}")
    return json.loads(raw.decode("utf-8"), object_pairs_hook=unique_pairs,
                      parse_constant=reject_constant)


def safe_relative(value: str) -> bool:
    p = PurePosixPath(value)
    return bool(value) and not p.is_absolute() and ".." not in p.parts \
        and "\\" not in value and ":" not in value and str(p) == value


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dependency_errors(items: list[dict[str, Any]]) -> list[str]:
    errors: list[str] = []
    ids = [item["id"] for item in items]
    if len(set(ids)) != len(ids):
        errors.append("Duplicate task IDs")
    known = set(ids)
    graph: dict[str, list[str]] = {}
    for item in items:
        graph[item["id"]] = item["dependencies"]
        if set(item["dependencies"]) - known:
            errors.append(f"Unknown task dependency: {item['id']}")
    active: set[str] = set()
    complete: set[str] = set()

    def visit(node: str) -> None:
        if node in active:
            raise ValueError(f"Task dependency cycle at {node}")
        if node in complete or node not in graph:
            return
        active.add(node)
        for dep in graph[node]:
            visit(dep)
        active.remove(node)
        complete.add(node)

    try:
        for node in graph:
            visit(node)
    except ValueError as exc:
        errors.append(str(exc))
    return errors


def traceability_errors(root: Path) -> list[str]:
    tasks = load_json(root / "orchestration/tasks.json")["tasks"]
    requirements = load_json(root / "quality/requirements.json")["requirements"]
    errors = dependency_errors(tasks)
    req_map = {r["id"]: r for r in requirements}
    test_ids = [r["acceptance_test_id"] for r in requirements]
    if len(req_map) != len(requirements) or len(set(test_ids)) != len(test_ids):
        errors.append("Duplicate requirement or acceptance IDs")
    seen: list[str] = []
    for task in tasks:
        if not task["requirements"]:
            errors.append(f"No requirements for {task['id']}")
        if task["model"] != "gpt-5.6-luna" or task["reasoning_effort"] != "max":
            errors.append(f"Wrong descendant model/effort for {task['id']}")
        for rid in task["requirements"]:
            seen.append(rid)
            req = req_map.get(rid)
            if req is None or req["task_id"] != task["id"]:
                errors.append(f"Broken task/requirement mapping: {task['id']} / {rid}")
            elif req["acceptance_test_id"] not in task["acceptance_tests"]:
                errors.append(f"Missing acceptance mapping: {rid}")
    if set(seen) != set(req_map) or len(seen) != len(requirements):
        errors.append("Requirements are missing or multiply assigned")
    policy = load_json(root / "config/orchestration-policy.json")
    expected = {"maximum_descendant_depth": 3, "descendant_model": "gpt-5.6-luna",
                "descendant_reasoning_effort": "max", "leaf_may_spawn": False,
                "phase_2_allowed": False, "auto_merge": False, "auto_deploy": False}
    for key, value in expected.items():
        if policy.get(key) != value:
            errors.append(f"Orchestration policy mismatch: {key}")
    return errors


def verify(root: Path) -> list[str]:
    errors: list[str] = []
    try:
        manifest = load_json(root / "PACKAGE_MANIFEST.json")
        entries = manifest["files"]
        names = [entry["path"] for entry in entries]
        if len(names) != len(set(names)) or not all(safe_relative(n) for n in names):
            return ["Unsafe or duplicate manifest path"]
        if any(n in {"PACKAGE_MANIFEST.json", "SHA256SUMS"} for n in names):
            return ["Manifest must exclude its own metadata and SHA256SUMS"]
        expected_files = set(names) | {"PACKAGE_MANIFEST.json", "SHA256SUMS"}
        actual_files: set[str] = set()
        for path in root.rglob("*"):
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                errors.append(f"Symlink forbidden: {relative}")
            if "__pycache__" in path.parts:
                continue  # Generated interpreter cache is not a distributed payload.
            if path.is_file():
                actual_files.add(relative)
        if actual_files != expected_files:
            errors.append(f"Inventory mismatch; missing={sorted(expected_files-actual_files)}, "
                          f"extra={sorted(actual_files-expected_files)}")
        for entry in entries:
            path = root / entry["path"]
            if not path.is_file() or path.is_symlink():
                errors.append(f"Missing/unsafe payload: {entry['path']}")
            elif path.stat().st_size != entry["bytes"] or digest(path) != entry["sha256"]:
                errors.append(f"Payload integrity mismatch: {entry['path']}")
        if manifest["payload_file_count"] != len(entries):
            errors.append("Payload count mismatch")
        if manifest["total_distributed_files"] != len(entries) + 2:
            errors.append("Total distributed-file count mismatch")
        sums: dict[str, str] = {}
        for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
            match = re.fullmatch(r"([0-9a-f]{64})  (.+)", line)
            if not match or not safe_relative(match[2]) or match[2] in sums:
                errors.append("Malformed/duplicate checksum entry")
                continue
            sums[match[2]] = match[1]
        if set(sums) != expected_files - {"SHA256SUMS"}:
            errors.append("Checksum inventory mismatch")
        for name, recorded in sums.items():
            path = root / name
            if not path.is_file() or digest(path) != recorded:
                errors.append(f"Checksum mismatch: {name}")
        for name in names:
            path = root / name
            if path.suffix == ".json":
                load_json(path)
            elif path.suffix == ".toml":
                tomllib.loads(path.read_text(encoding="utf-8"))
        errors.extend(traceability_errors(root))
        for path in root.rglob("*.md"):
            for link in re.findall(r"\[[^\]]*\]\(([^)]+)\)", path.read_text(encoding="utf-8")):
                if "://" in link or link.startswith(("#", "mailto:")):
                    continue
                target = link.split("#", 1)[0]
                if target and not (path.parent / target).exists():
                    errors.append(f"Broken local link: {path.name}: {link}")
    except (OSError, ValueError, KeyError, TypeError) as exc:
        errors.append(f"Package validation error: {exc}")
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    args = parser.parse_args()
    errors = verify(args.root.resolve())
    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print("PASS: package inventory, SHA-256, JSON/TOML, task DAG, traceability and local links")
    print("Scope: instruction-package checks only; no product, model, host or deployment proof.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
