#!/usr/bin/env python3
"""Validate proposed schema fixtures locally; not a production workflow compiler."""
from __future__ import annotations
import sys
from pathlib import Path
from typing import Any
from verify_package import load_json


def acyclic(nodes: set[str], edges: list[tuple[str, str]]) -> list[str]:
    errors: list[str] = []
    graph = {node: [] for node in nodes}
    for source, target in edges:
        if source not in nodes or target not in nodes:
            errors.append("Unknown graph endpoint")
        else:
            graph[source].append(target)
    active: set[str] = set()
    done: set[str] = set()

    def walk(node: str) -> None:
        if node in active:
            raise ValueError("Unbounded graph cycle")
        if node in done:
            return
        active.add(node)
        for child in graph[node]:
            walk(child)
        active.remove(node)
        done.add(node)

    try:
        for node in nodes:
            walk(node)
    except ValueError as exc:
        errors.append(str(exc))
    return errors


def seed_semantic_errors(data: Any) -> list[str]:
    """Representative sample invariants only, not full product semantics."""
    errors: list[str] = []
    version = data.get("schema_version")
    if version == "ascension.workflow/v1":
        graph_ids = [g["id"] for g in data["graphs"]]
        if len(set(graph_ids)) != len(graph_ids) or data["entry_graph"] not in graph_ids:
            errors.append("Duplicate/unknown graph identity")
        for graph in data["graphs"]:
            ids = [n["id"] for n in graph["nodes"]]
            if len(set(ids)) != len(ids) or graph["entry_node"] not in ids:
                errors.append("Duplicate/unknown node identity")
            errors.extend(acyclic(set(ids), [(e["from"], e["to"]) for e in graph["edges"]]))
            if data["mode"] == "strict" and any(n["kind"] == "adaptive_region" for n in graph["nodes"]):
                errors.append("Adaptive region in strict fixture")
            for node in graph["nodes"]:
                if node["kind"] == "execute_action":
                    if node["config"]["proposal_from"]["node_id"] not in ids:
                        errors.append("Unknown action proposal source")
    elif version == "ascension.plan/v1":
        ids = [n["id"] for n in data["nodes"]]
        if len(set(ids)) != len(ids) or data["output"]["node_id"] not in ids:
            errors.append("Duplicate/unknown plan node identity")
        edges = [(dep, n["id"]) for n in data["nodes"] for dep in n["depends_on"]]
        errors.extend(acyclic(set(ids), edges))
    elif version == "ascension.workflow-run/v1":
        if data["pending_operation"] and data["status"] in {"completed", "cancelled"}:
            errors.append("Terminal safe state cannot discard pending operation")
    elif version == "ascension.workflow-event/v1":
        if data["event_type"] == "operation_unknown" and data["payload"].get("classification") != "unknown":
            errors.append("Unknown event classification mismatch")
    return errors


def validate(root: Path) -> tuple[int, list[str]]:
    try:
        import jsonschema
    except ImportError:
        return -1, ["Optional jsonschema package is not installed; no installation was attempted."]
    errors: list[str] = []
    fixtures = load_json(root / "examples/fixture-index.json")["fixtures"]
    for schema_path in root.rglob("*.schema.json"):
        try:
            jsonschema.Draft202012Validator.check_schema(load_json(schema_path))
        except (ValueError, jsonschema.SchemaError) as exc:
            errors.append(f"Invalid schema {schema_path.name}: {exc}")
    for fixture in fixtures:
        name, expected = fixture["path"], fixture["expected"]
        try:
            data = load_json(root / name)
        except (ValueError, UnicodeError):
            if expected != "parse_invalid":
                errors.append(f"Unexpected parse rejection: {name}")
            continue
        if expected == "parse_invalid":
            errors.append(f"Malformed fixture parsed successfully: {name}")
            continue
        schema = load_json(root / fixture["schema"])
        # This package uses inline schemas only; no external reference retrieval is needed.
        validation_errors = list(jsonschema.Draft202012Validator(schema).iter_errors(data))
        if expected == "schema_invalid":
            if not validation_errors:
                errors.append(f"Invalid fixture accepted by schema: {name}")
            continue
        if validation_errors:
            errors.append(f"Unexpected schema rejection: {name}: {validation_errors[0].message}")
            continue
        semantics = seed_semantic_errors(data)
        if expected == "semantic_invalid":
            if not semantics:
                errors.append(f"Invalid semantic fixture accepted: {name}")
        elif semantics:
            errors.append(f"Unexpected seed-semantic rejection: {name}: {semantics}")
    return len(fixtures), errors


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    count, errors = validate(root)
    if count == -1:
        print(f"SKIPPED: {errors[0]}")
        return 2
    if errors:
        for error in errors:
            print(f"FAIL: {error}", file=sys.stderr)
        return 1
    print(f"PASS: {count} positive/negative fixtures and all proposed JSON Schemas")
    print("Scope: seed fixtures only; no production compiler/runtime/host validation.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
