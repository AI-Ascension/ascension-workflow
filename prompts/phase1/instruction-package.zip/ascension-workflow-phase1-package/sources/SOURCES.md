# Primary sources and evidence scope

All product requirements in this package are proposed implementation instructions unless explicitly described as source-derived. Exact source review scopes appear below. Mutable branch URLs must be pinned again before implementation; current package source review does not certify a future head. No live host, provider, or game test was run while preparing the archive.

## S01 — Harness baseline and architectural boundary

Branch SHA rechecked for this package; README inspected in the preceding architecture review.

Supports: Harness main fc44d3e; coordination/provider/records ownership and existing runtime/replay evidence limits.

- https://api.github.com/repos/AI-Ascension/sts2-harness/branches/main
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/README.md

## S02 — Existing episode runner and dispatch path

Inspected in preceding read-only architecture review at this pinned commit.

Supports: Bounded runner, per-run machine/ledger, policy routing, dispatch and uncertain-effect handling.

- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/runner.rs
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/runner_impl.rs
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/runner_steps.rs
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/runner_actions.rs

## S03 — Observation and coordinator state

Observation file re-read for this package; state machine inspected in prior review.

Supports: Coarse stages, actionability firewall, generation identity and pending-transition state.

- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/observation.rs
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/state_machine.rs

## S04 — Bounded existing gameplay action plans

Inspected in prior review at pinned commit.

Supports: Eight-action maximum and compatibility/settlement checks; not a dynamic workflow engine.

- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/action_plan.rs

## S05 — Decision source and hard constraints

Inspected in prior review at pinned commit.

Supports: Provider-neutral DecisionSource, current legal catalog, and string instruction constraints.

- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/crates/harness/src/episode/policy_router.rs

## S06 — Harness contributor boundaries and coding standards

Coding standards re-read for this package; AGENTS inspected in prior review.

Supports: Rust/toolchain/file limits, explicit ports, privacy, evidence, and required checks.

- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/AGENTS.md
- https://github.com/AI-Ascension/sts2-harness/blob/fc44d3ef65fefa6d13ecd5f690e5335a6ef60080/docs/CODING_STANDARDS.md

## S07 — Gateway authority and restart limitations

Mutable main source read in prior architecture review; mandatory execution-time refresh.

Supports: Attached-runtime limitations include lease renewal/TTL and durable boot epoch gaps; newer profiles need exact evidence.

- https://github.com/AI-Ascension/sts2-gateway/blob/main/README.md

## S08 — MCP mappings and runtime capability limits

Mutable main source read in prior review; refresh.

Supports: Thin MCP/gateway path, operation outcome semantics, map/expert/co-op qualification.

- https://github.com/AI-Ascension/sts2-mcp-server/blob/main/README.md

## S09 — Game-mod host authority and native evidence

Mutable main source read in prior review; refresh.

Supports: Host-authoritative mutation and exact recorded gameplay/profile evidence only.

- https://github.com/AI-Ascension/sts2-game-mod/blob/main/README.md

## S10 — Protocol admission and map/co-op contracts

Mutable main source read in prior review; refresh.

Supports: Neutral contract owner with explicit consumers; map visibility/co-op reporting are not mutation authority.

- https://github.com/AI-Ascension/sts2-protocol/blob/main/README.md

## S11 — Watchdog responsibility and evidence

Bootstrap-branch source read in prior review; discover current default branch again.

Supports: Process supervision owner; no demonstrated general live-host recovery in the reviewed status.

- https://github.com/AI-Ascension/ascension-watchdog/blob/bootstrap/README.md

## S12 — Existing observability deployment boundary

Mutable main source read in prior review; refresh.

Supports: Existing OTLP observability deployment; not a scheduler store.

- https://github.com/AI-Ascension/ai-agent-observability/blob/main/README.md

## S13 — Official Luna model and reasoning settings

Official model documentation fetched 2026-09-09.

Supports: Documented model ID gpt-5.6-luna and max effort support; account/runtime access must still be verified.

- https://developers.openai.com/api/docs/models/gpt-5.6-luna

## S14 — Official subagent and configuration reference

Official documentation fetched 2026-09-09 via developers.openai.com redirects.

Supports: Default child model/effort and concurrency settings; actual client behavior requires preflight.

- https://learn.chatgpt.com/docs/agent-configuration/subagents
- https://learn.chatgpt.com/docs/config-file/config-reference

## S15 — SQLite WAL documentation

Official documentation fetched 2026-09-09.

Supports: Local-host WAL assumptions and commit synchronization behavior; proposed store choice only.

- https://www.sqlite.org/wal.html

## S16 — SQLite synchronization reference

Official documentation fetched 2026-09-09.

Supports: Durability configuration must be inspected and tested for the selected adapter/environment.

- https://www.sqlite.org/pragma.html#pragma_synchronous

## S17 — JSON Schema 2020-12

Official specification page fetched 2026-09-09.

Supports: Draft selected for proposed contract seeds; schemas alone do not establish semantic correctness.

- https://json-schema.org/draft/2020-12

## Provenance

The prompt/spec/fixture content is original synthesis for the requested AI-Ascension Phase-1 implementation. Sources are referenced, not bundled as full third-party documents or implementation code. Synthetic fixtures are authored for this package and are not observations of the actual game. User-established orchestration conventions are preserved: D0 root with three descendant layers, Luna Max descendants, isolated worktrees, bounded GitHub writes, and no implicit merge/deployment.
