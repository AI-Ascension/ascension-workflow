# Requirement and acceptance traceability

The initial package defines **90 mandatory requirements**, **32 work packages**, and **40 explicit fault-injection scenarios**. These are planned acceptance obligations, not tests reported as passed.

`requirements.json` gives each requirement a stable `WF-NNN` ID and a distinct `AT-NNN` acceptance ID. `orchestration/tasks.json` maps each requirement to its implementing work package and dependencies. `fault-injection-cases.json` enumerates cross-cutting `FI-NNN` scenarios. Each scenario must map to the affected requirements in the implementation's live evidence matrix before its task can close.

All entries start `not_started`, with empty implementation/evidence refs and null agent/commit assignments. Templates and packet validators must not convert these into completion. Add execution metadata at run time; preserve the original requirement IDs and acceptance meaning.

For every requirement, store the owning repository, exact implementation commit/path, named test implementation, exact executed command, environment/profile, exit code, evidence artifact digest, independent reviewer, date, and scope. Blocked native evidence is separate from implemented/component-tested status.

A task is complete only after its dependencies are accepted, its implementation exists, its tests were executed, and a different D3 verifier supplied evidence. The final candidate must pass integration again. No deletion or weakening of requirements to obtain a higher completion percentage.

`T28` can finish its reporting work with native gates explicitly blocked by missing authorization/environment, but the native requirements cannot be marked confirmed. Final orchestration compliance is also independently qualified when effective model/depth metadata cannot be established.
