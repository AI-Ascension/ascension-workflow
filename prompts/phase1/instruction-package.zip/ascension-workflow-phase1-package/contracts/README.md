# Proposed contract seeds — not production certification

These JSON Schema 2020-12 files provide concrete starting shapes and synthetic fixtures. They are not already accepted by the current harness. The implementing team must complete canonical owner admission, strict node registries, semantic typechecking, error-code contracts, compiled digest rules, expression/binding registries, and full event variants before claiming the production feature complete.

The workflow seed models DAG bodies, explicit loop/subworkflow nodes, typed registered operations, adaptive-region budgets, and an opaque protected action node. The plan seed deliberately has no mutation operation. It represents a small synthetic registry; production registry entries require typed input/output/context contracts and permission validation.

The event and run snapshot seeds are narrow illustrative projections, not the entire final journal. Expanding them requires typed discriminated payloads and the invariants in the spec; replacing strict shapes with arbitrary unbounded objects is not acceptable.

Schema validity does not establish graph semantics, current capabilities, safe authority, operation idempotency, correct settlement, or runtime compatibility. The package's sample semantic checks cover only representative fixtures. They are not a reusable production compiler and must not be copied as a second interpreter into the delivery repository.

All examples are synthetic and contain no actual game state, credentials, or user data. `annotations.synthetic=true` identifies fixture workflow content; production catalog provenance uses its own admitted artifact metadata rather than pretending production runs are synthetic.

Canonical execution artifacts belong to `sts2-harness`. `ascension-workflow` consumes immutable exported copies with producer commit/schema version/digest/provenance/conformance evidence. Shared downstream envelopes enter `sts2-protocol` only through its existing admission process.
