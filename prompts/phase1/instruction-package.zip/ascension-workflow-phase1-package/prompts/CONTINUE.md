# Resume execution without duplicating work

Read `00_START_HERE.md`, the master prompt, current source/integration locks, task/requirement/evidence ledgers, agent attestations, open path leases, and last result checkpoint. Inspect actual Git state and recorded issue/PR IDs. Do not trust stale memory or repeat creation calls blindly.

Reconcile changed heads, unfinished commits, live agent states, pending commands, and unresolved external operations. Never resend an uncertain mutation or reset an action ledger. Re-run the model/depth preflight if runtime configuration changed. Resume only dependency-ready tasks with real D0→D1→D2→D3 Luna Max delegation.

Continue implementation, independent verification, scoped repair, and exact-head integration until all safely executable Phase-1 requirements are complete. Keep Phase 2 excluded. Preserve scope/permissions and disclose unavailable tests, native capabilities, models, and GitHub operations. End with the final integration report, not another high-level plan.
