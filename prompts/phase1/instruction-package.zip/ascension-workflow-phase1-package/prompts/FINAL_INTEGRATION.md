# Final integration and independent completion audit

Read all accepted ADRs, requirement/task/evidence matrices, exact candidate source/artifact locks, model/depth attestations, and authorization records. Use a fresh D1→D2→D3 Luna Max independent review chain, within available global capacity; do not count self-review.

Verify the new delivery repository is substantive but has no interpreter, and the harness is the only workflow runtime. Check strict and dynamic working paths, real durable store, actual CLI/API processes, complete first-party catalog, offline replay, fault/authority/privacy tests, and explicit native capability limits.

Run current owner policy/format/Clippy/workspace suites and complete integrated conformance on the exact PR candidate revisions. Reconcile branch drift and scoped CI/conflicts. Recheck copied artifact bytes and final source locks. Confirm no placeholders, hidden fallbacks, ignored tests, unauthorized repository changes, or Phase-2 code.

Audit every requirement ID: implementation ref plus executed evidence, or a precise blocker. Review original negative tests and all crash windows. No P0/P1 authority, privacy, data-loss, or duplicate-effect issue may be hidden in a completion claim.

Prepare linked draft PRs and assign to the authenticated operator where supported. Report repo creation, commits, pushes, PRs, assignment, CI, merge, release, deployment, native tests, and orchestration compliance independently. Do not merge, publish, install, or deploy. Complete `templates/FINAL_REPORT.md`, close agents, and preserve a reproducible handoff.
